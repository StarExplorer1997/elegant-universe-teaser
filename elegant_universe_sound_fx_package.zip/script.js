
document.getElementById('hoverBtn').addEventListener('mouseenter', () => {
    new Audio('hover_chime.wav').play();
});

document.getElementById('clickBtn').addEventListener('click', () => {
    new Audio('select_beep.wav').play();
});
