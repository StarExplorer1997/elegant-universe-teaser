
# Elegant Universe Teaser Site

## Launching with GitHub Pages
1. Upload all files from this ZIP into your GitHub repo.
2. Go to Settings > Pages.
3. Set source to 'main' branch and root directory (`/`).
4. Wait a few minutes, then access your live teaser site!

This teaser includes interactive elements, hover effects, and ambient background support.

Created with love and starlight.
